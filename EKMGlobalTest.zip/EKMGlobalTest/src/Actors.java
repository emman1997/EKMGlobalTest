
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Actors{

public static void main(String[] args)
{
	Actors a= new Actors(); //Creating new object for Actors
	
	a.searchActorsByName();   //Each section separated in their own methods to make it look cleaner
	a.searchActorsByID();
	a.addActor();
	a.updateActors();
    
}

void searchActorsByName() {
	 double count = 0,countBuffer=0,countLine=0;
	    String lineNumber = "";
	    String filePath = "C:\\Users\\emman\\eclipse-workspace\\EKMGlobalTest\\actors.txt";
	    BufferedReader br;
	    String inputSearch = "Sandra"; //Haven't created an input system for user. Will have to change value for desired search
	    String line = "";
	    Actors a= new Actors(); 
	    
	    /* try (Scanner reader = new Scanner(filePath)) {
			reader.useDelimiter("\\s*(name|actorID|height|dob)=");
		}*/
	    
	    try (Scanner reader = new Scanner(filePath)) {
	    	reader.useDelimiter("\\s*(name|actorID|height|dob)=");  //This is where the values are assigned to the text file
	        br = new BufferedReader(new FileReader(filePath));
	        try {
	            while((line = br.readLine()) != null)
	            {
	                countLine++;
	                System.out.println(line);  //Outputs the values of the whole text file, needs to be filtered for search.
	                String[] words = line.split(" ");

	                for (String word : words) {
	                  if (word.equals(inputSearch)) {
	                    count++;
	                    countBuffer++;
	                  }
	                }

	                if(countBuffer > 0)
	                {
	                    countBuffer = 0;
	                    lineNumber += countLine + ",";
	                }

	            }
	            
	            br.close();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	    } catch (FileNotFoundException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }
	    
	       // Calling the function to add actors before displaying details

	    System.out.println("How many times its found--"+count);
	    System.out.println("Word that matches--"+lineNumber);
	    System.out.println(inputSearch);
	    
}

void searchActorsByID(){
	double count = 0,countBuffer=0,countLine=0;
    String lineNumber = "";
    String filePath = "C:\\Users\\emman\\eclipse-workspace\\EKMGlobalTest\\actors.txt";
    BufferedReader br;
    String inputSearch = "1002"; //Haven't created an input system for user. Will have to change value for desired search
    String line = "";
    Actors a= new Actors(); 
    
    /* try (Scanner reader = new Scanner(filePath)) {
		reader.useDelimiter("\\s*(name|actorID|height|dob)=");
	}*/
    
    try (Scanner reader = new Scanner(filePath)) {
    	reader.useDelimiter("\\s*(name|actorID|height|dob)=");  //This is where the values are assigned to the text file
        br = new BufferedReader(new FileReader(filePath));
        try {
            while((line = br.readLine()) != null)
            {
                countLine++;
                String[] words = line.split(" ");

                for (String word : words) {
                  if (word.equals(inputSearch)) {
                    count++;
                    countBuffer++;
                  }
                }

                if(countBuffer > 0)
                {
                    countBuffer = 0;
                    lineNumber += countLine + ",";
                }

            }
            
            br.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    
       // Calling the function to add actors before displaying details

    System.out.println(inputSearch);
}

void addActor(){  
	String filePath = "C:\\Users\\emman\\eclipse-workspace\\EKMGlobalTest\\actors.txt";
	Scanner scan = new Scanner(System.in);   //This section will to add the user to the text file
    System.out.println("Name: ");
    String name = scan.next();
    System.out.println("ID: ");
    int id = scan.nextInt();
    System.out.println("Height: ");
    float height = scan.nextFloat();
    System.out.println("Date Of Birth: ");
    String DOB = scan.next();
    

    try(FileWriter fw = new FileWriter(filePath, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
            {
                out.println(name + "," + id + "," + height + "," + DOB); 
            } catch (IOException e) {
                        //exception handling left as an exercise for the reader
            }
    //Check the text file, it will have update it with your new inputted value. Validation has not been added
    
	}  

void updateActors() {
	String filePath = "C:\\Users\\emman\\eclipse-workspace\\EKMGlobalTest\\actors.txt";
    //Scanner class to read the file
    Scanner sc = new Scanner((filePath));
    //instantiating the StringBuffer class
    StringBuffer buffer = new StringBuffer();
    //Reading lines of the file and appending them to StringBuffer
    while (sc.hasNextLine()) {
       buffer.append(sc.nextLine()+System.lineSeparator());
    }
    String fileContents = buffer.toString();
    System.out.println("Contents of the file: "+fileContents);
    //closing the Scanner object
    sc.close();
    String oldLine = "Sandra";  //Taking the value of Sandra in the text file
    String newLine = "Rachel";
    //Replacing the old line with new line of text file
    fileContents = fileContents.replaceAll(oldLine, newLine);
    //instantiating the FileWriter class
    
	
}



}